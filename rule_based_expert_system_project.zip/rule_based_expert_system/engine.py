"""Generic forward-chaining rule engine."""
from dataclasses import dataclass
from typing import FrozenSet, Iterable

@dataclass(frozen=True)
class Rule:
    name: str
    conditions: FrozenSet[str]
    conclusion: str
    explanation: str

class ForwardChainingEngine:
    def __init__(self, rules: Iterable[Rule]):
        self.rules = list(rules)

    def run(self, initial_facts):
        facts = set(initial_facts)
        log = []
        fired_rules = set()

        while True:
            new_fact_added = False
            for rule in self.rules:
                if rule.name in fired_rules:
                    continue
                if rule.conditions.issubset(facts):
                    fired_rules.add(rule.name)
                    if rule.conclusion not in facts:
                        facts.add(rule.conclusion)
                        new_fact_added = True
                    log.append({
                        "rule": rule.name,
                        "conditions": sorted(rule.conditions),
                        "conclusion": rule.conclusion,
                        "explanation": rule.explanation,
                    })
            if not new_fact_added:
                break

        return facts, log
