"""Educational symptom knowledge base. Not for medical diagnosis."""
from engine import Rule

SYMPTOMS = [
    ("fever", "Fever"),
    ("cough", "Cough"),
    ("fatigue", "Fatigue"),
    ("body_aches", "Body aches"),
    ("high_fever", "High fever"),
    ("sore_throat", "Sore throat"),
    ("runny_nose", "Runny nose"),
    ("sneezing", "Sneezing"),
    ("itchy_eyes", "Itchy eyes"),
    ("shortness_of_breath", "Shortness of breath"),
    ("chills", "Chills"),
    ("loss_of_taste_smell", "Loss of taste or smell"),
    ("nausea", "Nausea"),
    ("diarrhea", "Diarrhea"),
    ("headache", "Headache"),
    ("rash", "Rash"),
]

RULES = [
    Rule("R1", frozenset({"fever", "cough", "fatigue"}), "viral_pattern",
         "Fever, cough and fatigue match a general viral-illness pattern."),
    Rule("R2", frozenset({"cough", "shortness_of_breath"}), "respiratory_pattern",
         "Cough together with shortness of breath suggests a respiratory pattern."),
    Rule("R3", frozenset({"runny_nose", "sneezing"}), "upper_respiratory_irritation",
         "Runny nose and sneezing indicate upper-respiratory irritation."),
    Rule("R4", frozenset({"viral_pattern", "body_aches", "high_fever"}), "possible_influenza_pattern",
         "The viral pattern plus body aches and high fever matches an influenza-like pattern."),
    Rule("R5", frozenset({"upper_respiratory_irritation", "sore_throat"}), "possible_common_cold_pattern",
         "Upper-respiratory irritation with sore throat matches a common-cold-like pattern."),
    Rule("R6", frozenset({"viral_pattern", "loss_of_taste_smell"}), "possible_covid_pattern",
         "The viral pattern plus loss of taste or smell warrants consideration of COVID-19 testing."),
    Rule("R7", frozenset({"respiratory_pattern", "high_fever", "chills"}), "urgent_respiratory_review",
         "Respiratory symptoms with high fever and chills need prompt medical assessment."),
    Rule("R8", frozenset({"runny_nose", "sneezing", "itchy_eyes"}), "possible_allergy_pattern",
         "Runny nose, sneezing and itchy eyes match an allergy-like pattern."),
    Rule("R9", frozenset({"nausea", "diarrhea"}), "gastrointestinal_pattern",
         "Nausea together with diarrhea indicates a gastrointestinal symptom pattern."),
    Rule("R10", frozenset({"headache", "fever", "rash"}), "urgent_medical_review",
         "Headache, fever and rash together require urgent professional medical review."),
]

CONCLUSIONS = {
    "possible_influenza_pattern": "Possible influenza-like pattern",
    "possible_common_cold_pattern": "Possible common-cold-like pattern",
    "possible_covid_pattern": "Possible COVID-19 pattern — consider testing",
    "urgent_respiratory_review": "Prompt medical assessment recommended",
    "possible_allergy_pattern": "Possible allergy-like pattern",
    "gastrointestinal_pattern": "Gastrointestinal symptom pattern",
    "urgent_medical_review": "Urgent medical review recommended",
}
