import unittest
from engine import ForwardChainingEngine
from knowledge_base import RULES

class ExpertSystemTests(unittest.TestCase):
    def test_multi_step_forward_chaining(self):
        facts, log = ForwardChainingEngine(RULES).run(
            {"fever", "cough", "fatigue", "body_aches", "high_fever"}
        )
        self.assertIn("viral_pattern", facts)
        self.assertIn("possible_influenza_pattern", facts)
        self.assertEqual([item["rule"] for item in log[:2]], ["R1", "R4"])

    def test_unmatched_facts(self):
        facts, log = ForwardChainingEngine(RULES).run({"sunny_weather"})
        self.assertEqual(facts, {"sunny_weather"})
        self.assertEqual(log, [])

    def test_rule_chain_for_allergy(self):
        facts, _ = ForwardChainingEngine(RULES).run(
            {"runny_nose", "sneezing", "itchy_eyes"}
        )
        self.assertIn("possible_allergy_pattern", facts)

if __name__ == "__main__":
    unittest.main()
