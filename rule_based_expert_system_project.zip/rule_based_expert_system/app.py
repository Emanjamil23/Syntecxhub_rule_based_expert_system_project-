from flask import Flask, render_template_string, request
from engine import ForwardChainingEngine
from knowledge_base import SYMPTOMS, RULES, CONCLUSIONS

app = Flask(__name__)
PAGE = """
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Rule-Based Expert System</title>
<style>
body{font-family:Arial,sans-serif;background:#f3f0ff;color:#21124b;margin:0;padding:28px}
main{max-width:850px;margin:auto;background:white;padding:28px;border-radius:18px;box-shadow:0 8px 28px #24104a18}
h1{margin-top:0} .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:10px}
label{background:#f7f5ff;padding:12px;border-radius:9px}button{margin-top:20px;background:#43218a;color:white;border:0;padding:13px 22px;border-radius:9px;font-size:16px;cursor:pointer}
.card{background:#f7f5ff;padding:16px;border-radius:10px;margin:12px 0} .warning{color:#8b2500;font-weight:bold}
small{color:#625b70}
</style></head><body><main>
<h1>Rule-Based Expert System</h1><p>Choose any symptoms, then run the forward-chaining engine.</p>
<p class="warning">Educational demonstration only. This is not a medical diagnosis.</p>
<form method="post"><div class="grid">
{% for key,label in symptoms %}<label><input type="checkbox" name="symptoms" value="{{key}}" {% if key in selected %}checked{% endif %}> {{label}}</label>{% endfor %}
</div><button type="submit">Run Expert System</button></form>
{% if submitted %}
<h2>Inferred results</h2>
{% if results %}{% for result in results %}<div class="card">{{result}}</div>{% endfor %}
{% else %}<p>No conclusion could be inferred from the selected symptoms.</p>{% endif %}
<h2>Reasoning path</h2>
{% if log %}{% for item in log %}<div class="card"><b>{{item.rule}}</b><br>IF {{item.conditions|join(' AND ')}}<br>THEN <b>{{item.conclusion}}</b><br><small>{{item.explanation}}</small></div>{% endfor %}
{% else %}<p>No rules were triggered.</p>{% endif %}
{% endif %}
<p><small>For severe symptoms or concerns, seek advice from a qualified healthcare professional.</small></p>
</main></body></html>
"""

@app.route("/", methods=["GET", "POST"])
def home():
    selected = set(request.form.getlist("symptoms")) if request.method == "POST" else set()
    submitted = request.method == "POST"
    facts, log = ForwardChainingEngine(RULES).run(selected) if submitted else (set(), [])
    results = [label for key, label in CONCLUSIONS.items() if key in facts]
    return render_template_string(PAGE, symptoms=SYMPTOMS, selected=selected,
                                  submitted=submitted, results=results, log=log)

if __name__ == "__main__":
    app.run(debug=True)
