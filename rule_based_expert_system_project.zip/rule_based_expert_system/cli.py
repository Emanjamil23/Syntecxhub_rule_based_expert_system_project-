from engine import ForwardChainingEngine
from knowledge_base import SYMPTOMS, RULES, CONCLUSIONS

def main():
    print("=" * 58)
    print("       RULE-BASED EXPERT SYSTEM - SYMPTOM CHECKER")
    print("=" * 58)
    print("Educational demonstration only — not a medical diagnosis.\n")
    print("Select the symptoms you currently have:")
    selected = set()

    for index, (key, label) in enumerate(SYMPTOMS, start=1):
        while True:
            answer = input(f"{index:2}. {label}? (y/n): ").strip().lower()
            if answer in {"y", "yes"}:
                selected.add(key)
                break
            if answer in {"n", "no"}:
                break
            print("Please enter y or n.")

    engine = ForwardChainingEngine(RULES)
    facts, log = engine.run(selected)

    print("\n" + "=" * 58)
    print("INFERENCE / REASONING LOG")
    print("=" * 58)
    if not log:
        print("No rules matched the selected symptoms.")
    else:
        for step, item in enumerate(log, start=1):
            print(f"\nStep {step} — {item['rule']}")
            print("  IF:", " AND ".join(item["conditions"]))
            print("  THEN:", item["conclusion"])
            print("  WHY:", item["explanation"])

    print("\n" + "=" * 58)
    print("RESULTS")
    print("=" * 58)
    results = [label for key, label in CONCLUSIONS.items() if key in facts]
    if results:
        for result in results:
            print("•", result)
    else:
        print("No conclusion could be inferred from the selected symptoms.")

    print("\nIf you have severe symptoms or are worried, contact a qualified healthcare professional.")
    print("This program cannot diagnose or replace medical advice.")

if __name__ == "__main__":
    main()
